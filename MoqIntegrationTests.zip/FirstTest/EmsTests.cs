﻿using EMS;
using NUnit.Framework;

namespace FirstTest
{
    class EmsTests
    {
        [Test]
        public void Test_Login()
        {
            //Arrange 
            string username = "meena";
            string password = "aneem*!";
            string expectedResult = "Login Successful";

            //Act
            string actualResult = new Program().Login(username, password);

            //Assert
            Assert.AreEqual(expectedResult, actualResult);
        }
    }
}
