using NUnit.Framework;
using System;

namespace FirstTest
{
    public class Tests
    {

        int n1;
        int n2;
        int expectedResult;

        [SetUp]
        public void Setup()
        {
            n1 = 100;
            n2 = 200;
            expectedResult = 0;
        }



        public static object[] MultiplyCases =
        {
                         new object[]{100,200,20000},
                         new object[]{-100,-200,20000},
                         new object[]{-100,200,-20000},
                         new object[]{100,-200,-20000}

        };

        [TestCaseSource(nameof(MultiplyCases))]
        public void Test_Multiply(int n1, int n2, int expectedResult)
        {
            int actualResult = Multiply(n1, n2);
            Assert.AreEqual(expectedResult, actualResult);
        }

        private int Multiply(int n1, int n2)
        {
            return n1 * n2;
        }

        [TestCaseSource(typeof(Examples), nameof(Examples.SubtractCases))]
        public void Test_Subtract(int n1, int n2, int expectedResult)
        {
            //Act
            int actualResult = Subtract(n1, n2);
            Assert.AreEqual(expectedResult, actualResult);
        }

        private int Subtract(int n1, int n2)
        {
            return n1 - n2;
        }

        [TestCase(100, 200, 300)]
        [TestCase(-100, -200, -300)]
        [TestCase(-100, 200, 100)]
        [TestCase(100, -200, -100)]
        public void Test_Add(int n1, int n2, int expectedResult)
        {
            //Arrange - Act - Assert

            //Act: Call the Add Function
            int actualResult = Add(n1, n2);

            //Assert: Verify that actual and expected results are equal
            Assert.AreEqual(expectedResult, actualResult);
        }

        private int Add(int n1, int n2)
        {
            return n1 + n2;
        }

        [TestCaseSource(typeof(Examples), nameof(Examples.DivideCases))]
        public void Test_Divide(float? n1, float? n2, float expectedResult)
        {
            float? actualResult = Divide(n1, n2);
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestCaseSource(typeof(Examples), nameof(Examples.DivideFailCases))]
        public void Test_Divide_Two_Numbers_Which_Are_Of_Invalid_Type(float? n1, float? n2, dynamic expectedResult)
        {
            //without constraints
            Assert.Throws<DivideByZeroException>(() => Divide(n1,n2));
            
            //with constraints
            Assert.Throws(Is.TypeOf<DivideByZeroException>(), ()=> Divide(n1,n2));

            Assert.Catch<ArithmeticException>(() => Divide(n1, n2));
            Assert.Throws(Is.InstanceOf<ArithmeticException>(), () => Divide(n1, n2));

            //Chaining
            Assert.Throws(Is.TypeOf<DivideByZeroException>()
                    .And.Message.EqualTo("Not allowed"), ()=>Divide(n1,n2));
        }

        private float? Divide(float? n1, float? n2)
        {
            if (n2 == 0f)
            {
                throw new DivideByZeroException("Not allowed");
            }
            if (n1 == null || n2 == null)
            {
                throw new DivideByZeroException("Not allowed");
            }
            return n1 / n2;
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }

        [Test]
        public void Test2()
        {
            Assert.Pass();
        }



    }
}