﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstTest
{
    public class Examples
    {
        public static object[] SubtractCases = 
            {
                         new object[]{100,200,-100},
                         new object[]{-100,-200,100},
                         new object[]{-100,200,-300},
                         new object[]{100,-200,300}
           };

        public static object[] DivideFailCases =
        {
            new object[] {100f,0f,new DivideByZeroException("Not allowed") },
            new object[] {null, null, new DivideByZeroException("Not allowed")}
        };

        public static object[] DivideCases()
        {
            return GetFromDummyDB();
        }

        private static object[] GetFromDummyDB()
        {
           return new object[] {
                         new object[] { 100f, 200f, 0.5f },
                         new object[] { -100f, -200f, 0.5f },
                         new object[] { -100f, 200f, -0.5f },
                         new object[] { 100f, -200f, -0.5f }

           };
        }
    }
}
