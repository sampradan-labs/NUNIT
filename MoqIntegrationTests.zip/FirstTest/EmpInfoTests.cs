﻿using EMS;
using NUnit.Framework;
using System;

namespace FirstTest
{
    public class EmpInfoTests
    {
        /// <summary>
        /// SCENARIO: Test getIncValue to get the increment value for Director
        /// BACKGROUND: EmpId=5001, ctc=9023432434, Designation=Director
        /// GIVEN: Forced call to a private method getIncValue()
        /// WHEN: getIncValue() is called
        /// THEN: getIncValue() method is accessible
        /// </summary>
        [Test]
        public void Test_GetIncValue()
        {
            //Arrange & Act
             var method = typeof(EmpInfo).GetMethod("getIncValue", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
            //Assert
            Assert.That(method, Is.Not.Null);
            Assert.That(method.Name == "getIncValue");
        }

        [Test]
        public void Test_EmpInfo_Constructor()
        {
            //Arrange & Act
            var obj = new EmpInfo();

            //Assert
            Assert.That(obj, Is.Not.Null);
            Assert.That(obj, Is.TypeOf(typeof(EmpInfo)));
        }

        [Test]
        public void Test_GetIncrement_For_Invalid_Designation() {
            //Arrange
            int empId = 1001;
            string Designation = "RH Executive";
            double ctc = 2000000;
            EmpInfo dummyEmp = new EmpInfo();

            //ACT
            //When error logged event occurs it sets the value of a property | field
            string __Message = "";
            dummyEmp.ErrorLogged += () => {
                __Message = "Error";
            };
            double incrementedSalary = dummyEmp.GetIncrement(empId, Designation, ctc);

            //Assert
            Assert.IsNotEmpty(__Message);
            Assert.That(__Message == "Error");
        }

       

        [Test]
        public void Test_Get_Employee_Detail_For_Valid_Employee()
        {
            //Arrange
            int empId = 1001;
            EmpInfo expectedResult = new EmpInfo()
            {
                EmpId = 1001,
                Name = "Preeti",
                Desig = "Developer",
                ManagerName = "Samprada",
                ProjectName = "NUnit",
                TotalLeaves = 1,
                Salary = 5000000
            };

            //Act
            EmpInfo actualResult = new EmpInfo().GetEmpInfo(empId);

            //Assert
            Assert.NotNull(actualResult);
            Assert.AreEqual(expectedResult.Name, actualResult.Name);
            Assert.AreEqual(expectedResult.Desig, actualResult.Desig);
            Assert.AreEqual(expectedResult.ManagerName, actualResult.ManagerName);
            Assert.AreEqual(expectedResult.ProjectName, actualResult.ProjectName);
            Assert.AreEqual(expectedResult.TotalLeaves, actualResult.TotalLeaves);
            Assert.AreEqual(expectedResult.Salary, actualResult.Salary);
        }

        [TestCase(-999)]
        [TestCase(null)]
        public void Test_Get_Employee_Detail_For_Invalid_Employee(int? empId)
        {
            //Arrange
            //Refer to [TestCase]

            //Act & Assert
            Assert.Throws(Is.TypeOf<Exception>()
                   .And.Message.EqualTo("Invalid EmpId"), () => new EmpInfo().GetEmpInfo(empId));

        }
    }


}
