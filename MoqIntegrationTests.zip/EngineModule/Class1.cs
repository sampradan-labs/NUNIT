﻿using System;

namespace EngineModule
{
    public interface IEngine
    {
        public string Make { get; set; }
        public float Capacity { get; set; }
        public bool IsAuditComplete(IEngine e);
    }
}
