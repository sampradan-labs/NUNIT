﻿using System;

namespace AccessoryModule
{
    public interface IAccessory
    {
        public string Name { get; set; }
        public string Make { get; set; }
        public string Installation { get; set; }
        public double Cost { get; set; }
    }

    public class TrayTable : IAccessory
    {
        public string Name { get; set; }
        public string Make { get; set; }
        public string Installation { get; set; }
        public double Cost { get; set; }
    }
}
