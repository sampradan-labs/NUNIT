using NUnit.Framework;
using Moq;
using CarModule;
using EngineModule;

namespace MoqIntegrationTests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test_Car_Is_Instantiated_With_Valid_Engine()
        {
            Mock<IEngine> mockEngine = new Mock<IEngine>(MockBehavior.Default);
            Car myCar = new Car(mockEngine.Object);
            Assert.That(myCar, Is.Not.Null);
       }

        [Test]
        public void Test_Car_Engine_Audit_Complete_Is_Called()
        {
            //Arrange
            Mock<IEngine> mockEngine = new Mock<IEngine>();
            mockEngine.Setup(obj => obj.IsAuditComplete(Moq.It.IsAny<IEngine>()))
                        .Returns(() => true)
                        .Verifiable();

            //Act
            Car myCar = new Car(mockEngine.Object);
            myCar.CarEngine.IsAuditComplete(mockEngine.Object);

            //Assert
            Assert.That(myCar, Is.Not.Null);
            mockEngine.Verify(obj => obj.IsAuditComplete(mockEngine.Object), Times.Exactly(1));
        }

        /*
         Create an object of Car as myCar
         Mock<IAccessory> mock
         myCar.AddAccessory(mock.Object)
         mock.verify()
         */
    }
}