﻿using System;
using System.Collections.Generic;
using AccessoryModule;
using EngineModule;

namespace CarModule
{
    public class Car
    {
        public IEngine CarEngine { get; set; }
        public List<IAccessory> CarAccessories { get; private set; }

        public Car(IEngine e)
        {
            this.CarEngine = e;
        }

        public bool AddAccessory(IAccessory a)
        {
            this.CarAccessories.Add(a);
            return true;
        }
    }
}
