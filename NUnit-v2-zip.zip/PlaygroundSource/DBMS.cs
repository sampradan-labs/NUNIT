﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Input;

namespace PlaygroundSource
{
    class DBMS : IOps
    {

        IDbConnection con;
        IDbCommand command;


        public bool Delete(object[] detail)
        {
            throw new NotImplementedException();
        }

        public object[] GetDetails(string empId)
        {
            //con = new SqlConnection("");
            //command = con.CreateCommand();
            //command.CommandText = "select * from Employee where EmpId = "+empId;
            //command.ExecuteReader(CommandBehavior.CloseConnection);

            return new object[] { "Ganga", "Director", 500000000 };

        }

        public int InsertDetail(object[] detail)
        {
            throw new NotImplementedException();
        }

        public List<object[]> Select(object[] detail)
        {
            throw new NotImplementedException();
        }
    }
}
