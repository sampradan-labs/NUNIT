﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlaygroundSource
{
    interface IOps
    {
        object[] GetDetails(string empId);
        int InsertDetail(object[] detail);
        bool Delete(object[] detail);

        List<object[]> Select(object[] detail);
    }
}
