﻿using System;

namespace PlaygroundSource
{
    public class Calci
    {
        public static double Add(int v1, int v2)
        {
            return v1 + v2;
        }

        public static double Sub(int v1, int v2)
        {
            return v1 - v2;
        }
    }
}
