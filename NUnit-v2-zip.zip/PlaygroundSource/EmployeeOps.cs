﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

[assembly: InternalsVisibleTo("Playground")]
namespace PlaygroundSource
{
    public class EmployeeOps
    {
        public static event EventHandler<Guid> ErrorLogged;

            public static double Increment(string pEmpId, string pDesignation, double pCtc)
            {
          

                switch (pDesignation)
                {
                    case "Director":
                        return getIncValue();
                    case "CEO":
                        return 25;

                    case "Product Lead":
                        return 20;

                    case "Software Engineer":
                        return 18;

                    default:
                    ErrorLogged?.Invoke(null, Guid.NewGuid());
                        throw new Exception("Invalid Designation");
                }
            }

        
        private static double getIncValue()
        {
            return 40;
        }

        [Test]
        public void Test_GetIncValue()
        {
            Assert.AreEqual(40, getIncValue());
        }

        public int _PrivateProp { get; set; }
        private bool IsTrue()
        {
            return true;
        }
    }
}
