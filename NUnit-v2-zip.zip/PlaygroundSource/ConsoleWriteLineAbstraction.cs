﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlaygroundSource
{
    public class SomeProductionClass
    {
        private readonly IConsole _console;

        public SomeProductionClass(IConsole console)
        {
            _console = console;
        }

        public void findOccuranceMethod()
        {
            string str = "The Haunting of Hill House!";
            _console.WriteLine("String: " + str);
            string occurString = "o";
            string replaceString = "MDDS";

            var array = str.Split(new[] { occurString }, StringSplitOptions.None);
            var count = array.Length - 1;
            string result = string.Join(replaceString, array);

            _console.WriteLine("String after replacing a character: " + result);
            _console.WriteLine("Number of replaces made: " + count);
            _console.ReadLine();
        }
    }

    public interface IConsole
    {
        void WriteLine(string s);
        void ReadLine(); // void is enough for this example
    }

    // for use in production
    public class RealConsole : IConsole
    {
        public void WriteLine(string s)
        {
            Console.WriteLine(s);
        }
        public void ReadLine()
        {
            Console.ReadLine();
        }
    }

    // for use in unit tests
    public class TestConsole : IConsole
    {
        public void WriteLine(string s)
        {
            Contents.Add(s);
        }
        public void ReadLine()
        {
        }

        public List<string> Contents { get; } = new List<string>();
    }
}
