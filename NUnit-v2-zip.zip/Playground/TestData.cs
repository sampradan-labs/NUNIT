﻿using PlaygroundSource;
using System;
using System.Collections.Generic;
using System.Text;

namespace Playground
{
    internal class TestData
    {
        public static object[] data_TestAdd = {
            new object[]{ 100, 200, 300 },
            new object[]{ -100, 200, 100 },
            new object[]{ 100, -200, -100 },
            new object[]{ -100, -200, -300 },
            new object[]{ 100273, 2003456, 2103729 }
        };
    }

    internal class mockIOps : IOps
    {
        public object[] GetDetails(string empId) {
            return new object[] { "Ganga", "Director", 500000000 };
        }

        public int InsertDetail(object[] detail) {
            return 1;
        }

        public bool Delete(object[] detail)
        {
            return true;
        }

        public List<object[]> Select(object[] detail)
        {
            return new List<object[]>(){
                new object[] { "Ganga", "Director", 500000000 }
                };
        }

    }
}
