using System;
using NUnit.Framework;
using PlaygroundSource;

namespace Playground
{
    [TestFixture]
    public class Tests
    {
        int expectedResult;
        int n1; int n2;

        [OneTimeSetUp]
        public void Init() { 
        
        }

        [SetUp]
        public void Setup()
        {
            //Initializations for setting up testcase data
            n1 = 100;
            n2 = 200;
            expectedResult = 0;
        }

        [Test]
        [Ignore("To be done in Sprint 2")]
        public void TestMul() { 
            //Not yet implemented. TBD in Sprint 2
        }

        [Test]
        public void TestAdd()
        {
            //setup data for this verification
            //n1 =100, n2=200
            expectedResult = 300;
            //| Test Addition of 100, 200    | expected: 300 | actual: 300   | testcase status: PASS |
            
            Assert.AreEqual(expectedResult, Calci.Add(100, 200));
            n1 = 500;
            n2 = 400;
        }


        [TestCase(100, 200,300)]
        [TestCase(-100, 200, 100)]
        [TestCase(100, -200, -100)]
        [TestCase(-100, -200, -300)]
        [TestCase(100273, 2003456, 2103729)]
        public void TestAddSeries_Technique1(int n1, int n2, double expectedResult) {

            Assert.AreEqual(expectedResult, Calci.Add(n1, n2));
        }

        static object[] numData = { 
            new object[]{ 100, 200, 300 },
            new object[]{ -100, 200, 100 },
            new object[]{ 100, -200, -100 },
            new object[]{ -100, -200, -300 },
            new object[]{ 100273, 2003456, 2103729 }
        };

        [TestCaseSource("numData")]
        public void TestAddSeries_Technique2(int n1, int n2, double expectedResult)
        {

            Assert.AreEqual(expectedResult, Calci.Add(n1, n2));
        }

        [TestCaseSource(typeof(TestData), "data_TestAdd")]  //The datasource comes from class TestData -> data_TestAdd
        public void TestAddSeries_Technique3(int n1, int n2, double expectedResult)
        {

            Assert.AreEqual(expectedResult, Calci.Add(n1, n2));
        }

        [Test]
        public void TestSub()
        {
            //setup data for this verification
            //n1 =100, n2=200
            expectedResult = -100;
            //| Test Addition of 100, 200    | expected: 300 | actual: 300   | testcase status: PASS |

            Assert.AreEqual(expectedResult, Calci.Sub(100, 200));
            
        }

        

        

        [TearDown]
        public void CleanUp() { 
        
        }

        [OneTimeTearDown]
        public void FinalCleanUp()
        {

        }
    }


    

   
}