﻿using NUnit.Framework;
using PlaygroundSource;
using System;
using System.Collections.Generic;
using System.Text;

namespace Playground.Feature_Tests
{
    class TestConsoleWriteLine
    {
        [Test()]
        public void findOccuranceMethodTest()
        {
            // Arrange
            string expectedString = "The Haunting MDDSf Hill HMDDSuse!";
            int expectedCount = 2;
            var console = new TestConsole();
            var productionClass = new SomeProductionClass(console);

            // Act
            productionClass.findOccuranceMethod();

            // Assert
            Assert.AreEqual(3, console.Contents.Count);
            Assert.AreEqual("String: The Haunting of Hill House!", console.Contents[0]);
            Assert.AreEqual(
                $"String after replacing a character: {expectedString}",
                console.Contents[1]);
            Assert.AreEqual(
                $"Number of replaces made: {expectedCount}",
                console.Contents[2]);
        }
    }
}
