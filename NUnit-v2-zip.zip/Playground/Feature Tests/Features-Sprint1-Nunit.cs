﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities.DataCollection;
using NUnit.Framework;
using PlaygroundSource;

namespace Playground
{
    [TestFixture]
    class Features_Sprint1_Nunit
    {
        [TestCase("Ganga", "Director", 500000000, 40)]
        public void Test_Increment(string name, string designation, double ctc, int expectedresult)
        {
            Assert.AreEqual(expectedresult, PlaygroundSource.EmployeeOps.Increment(
                name,
                designation,
                ctc
                ));
        }


        [TestCase("12345", "PR", 1029398)]
        public void Test_Increment_ToRaiseErrorLoggedEvent(string name, string designation, double ctc) {
            //Dummy Data - ACT
            
            Guid? errorGuid=null;
            string msg="";
            //Creating a fake event handler to confirm the trigger

            EmployeeOps.ErrorLogged += (object sender, Guid e) => 
            {
                errorGuid = e;
                msg = "Error Logged invoked";
            };


            //Make the call to Increment() - ARRANGE     
            Assert.Throws<Exception>(() => EmployeeOps.Increment(name, designation, ctc), "Invalid Designation", null);


            //Assertions - ASSERT
            Assert.That(errorGuid, Is.Not.Null);
            Assert.That(msg, Is.EqualTo("Error Logged invoked"));
            Assert.AreEqual("Error Logged invoked", msg);
            
        }

       

        [Test]
        public void Test_EmployeeContainingAn()
        {
            //Dummy Test Data
            string[] employees = { "Anna", "Anu", "Hari Prakash", "Aniruddh Iyer" };

            //Assertions
            Assert.That(employees, Has.Some.Contains("an").IgnoreCase);
            Assert.That(employees, Has.Some.Match(".?n.*"));
                        
        }

        [TestCase("SIE-12345", new object[] { "Ganga", "Director", 500000000 })]
        public void Test_GetDetails(string empId, object[] expectedResult)
        {
            //Arrange

            //Act & Assert
            Assert.That(new mockIOps().GetDetails(empId), Is.EqualTo(expectedResult));
        }


    }
}
