﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using NUnit.Framework;
using PlaygroundSource;

namespace Playground.Code_Unit_Tests
{
    [TestFixture]
    class CodeUnit_Featue_Sprint1_Nunit
    {
        [Test]
        public void Test_GetValueForDesignation() {
            Assert.Pass();
        }

        [Test]
        public void Test_GetFromDB() {
            Assert.Pass();
        }

        [Test]
        public void Test_GetIncValue() {

            var method =typeof(EmployeeOps).GetMethod("getIncValue", 
               System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
            Assert.That(method, Is.Not.Null);
           
        }

        [Test]
        public void Test_DBMS_GetDetails() {
            Assert.Pass();
        }
        
    }
}
