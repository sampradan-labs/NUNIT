using NUnit.Framework;
using tobedeletedSource;

namespace tobedeleted
{
    [TestFixture]
    public class Tests
    {
        Guest guest;
        string passId, secretcode;

        [OneTimeSetUp]
        public void OneTimeInit()
        {
           guest  = new Guest();
        }

        [SetUp]
        public void InitData()
        {
            passId = "guest007";
            secretcode = "12345";
        }

       [TestCaseSource(typeof(GuestData), "ValidGuests")]
        public void Successful_GuestEntry(string passId, string secretcode) {
            
            bool expectedResult = true;            
            guest.PassId = passId;
            guest.SecretCode = secretcode;
            //Act
            bool actualResult = Party.GuestEntry(guest);

            //Assert .. In .Net AreEqual() function is called a Assertion / matcher
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestCase(100,200,300)]
        [TestCase(300, 200,500)]
        [TestCase(300, 400, 700)]
        public void Successful_Sum(int n1, int n2, int expectedResult)
        {
            int sum = n1 + n2;
            Assert.AreEqual(expectedResult, sum);
        }

        [Test]
        [Ignore("Will be implemented in Sprint 2.0")]
        public void Successful_GuestEntry_WithOTP() {
          
        }

        public void NormalFunction() {
            Assert.Pass();
        }
    }

    internal class GuestData
    {
        public static object[] ValidGuests { get; set; } = new object[] { 
                                                                    new object[] { "Ganga", "12345" },
                                                                    new object[] { "Bhola", "2468" },
                                                                    new object[] { "Paras", "12345" },
                                                                    new object[] { "Ashwini", "12345" }
                                                                   };
    }
}