﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using tobedeletedSource;

namespace tobedeleted.UnitTests
{
    [TestFixture]
    class JustSamples
    {
        /// <summary>
        /// GIVEN   A guestPassId = 'guest001'
        /// WHEN    guest001.ResetSecretCode is called
        /// THEN    The secretcode should be reset to  "12@345!"
        /// </summary>
        [Test]
        public void Test_VoidFunction_That_Sets_A_Public_Property()
        {
            var guest001 = new Guest();
            guest001.ResetSecretCode("guest001");

            Assert.AreEqual("12@345!", guest001.SecretCode);
        }

        /*
         GIVEN: A Party object, a new guest needs to be registered for the party "Freshers Party"
         WHEN:  Party.Register(ref Guest guest001)
         THEN:  On successfully being registered, guest001.GuestParty 
                is set to a new Party object & 
                the guest001.Party.Name = "Freshers Party"
         */
        [Test]
        public void Test_Guest_Registration_For_Fresher_Party()
        {
            //Setup
            Party freshersParty = new Party();
            Guest guest001 = new Guest();

            //Arrange
            freshersParty.Register(ref guest001);

            //Assert
            Assert.That(guest001.GuestParty, Is.Not.Null);
            Assert.AreEqual("Freshers Party", guest001.GuestParty.Name);
            
        }

        /*
         GIVEN: A Party object, a new guest needs to be registered for the party "Freshers Party"
         WHEN:  Party.Register(ref Guest guest001)
         THEN:  On successfully being registered, verify that "Registration successful" is printed on the console
         */
        [Test]
        public void Test_Registration_Successful_OnRegister() {
            //Setup
            MyConsole _myConsole = new MyConsole();
            Party freshersParty = new Party(_myConsole);
            Guest guest001 = new Guest();

            //Arrange
            freshersParty.Register(ref guest001);

            //Assert
            Assert.AreEqual("Registration Successful", 
                    _myConsole.Contents[_myConsole.Contents.Count - 1]);

        }

    }
    
}
