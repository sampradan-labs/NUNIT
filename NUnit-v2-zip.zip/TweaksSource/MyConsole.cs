﻿using System;
using System.Collections.Generic;
using System.Text;

namespace tobedeletedSource
{
    public class MyConsole
    {
        public List<string> Contents { get; private set; } 
                = new List<string>();

        public MyConsole()
            {
            }

        public void WriteLine(string s) {
            Console.WriteLine(s);
            this.Contents.Add(s);
        }

        public object ReadLine() {
            return Console.ReadLine();
        }
    }
}
