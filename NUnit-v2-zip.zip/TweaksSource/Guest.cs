﻿using System;
using System.Collections.Generic;
using System.Text;

namespace tobedeletedSource
{
    public class Guest
    {
        public string PassId { get; set; }
        public string SecretCode { get; set; }
        public Party GuestParty { get; set; }

        private string _changedSecretCode = string.Empty;

        public void ResetSecretCode(string passId)
        {
            this.PassId = passId;
            this.SecretCode = "12@345!";
        }

        
    }
}
