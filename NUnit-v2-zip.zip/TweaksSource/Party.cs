﻿using System;
using System.Collections.Generic;
using System.Text;

namespace tobedeletedSource
{
   

    public class Party
    {
        private MyConsole _myConsole;
        public Party() : this(new MyConsole())
        {            
        }

        public Party(MyConsole console)
        {
            _myConsole = console;
        }

        public string Name { get; set; }

        static object[] guestDb = new object[] {
                                           new object[] { "Ganga", "12345"},
                                           new object[] { "Bhola", "2468"},
                                           new object[] { "Paras", "12345"},
                                           new object[] { "Ashwini", "12345"}
                                                 };

        public static bool GuestEntry(Guest guest) {
            foreach (object[] item in guestDb)
            {
                if (item[0] == guest.PassId && item[1] == guest.SecretCode)
                {
                    return true;
                }
            }

            
            return false;
        }

        public void Register(ref Guest guest001)
        {
            this.Name = "Freshers Party";
            guest001.GuestParty = new Party() { Name = "Freshers Party" };
            _myConsole.WriteLine("Registration Successful");

        }
        
    }

}
