﻿using System;

namespace tobedeletedSource
{
    class Program
    {
        private static event Action<object, string, bool> UserDefined;

        //Declaration of event: event <Type> <eventName>
        static event Action<object, Guid> SomeThingDifferent;

       static event Action DoSomething;

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            //Subscribe events
            Program.DoSomething += () => { Console.WriteLine("Did Something"); };

            Program.SomeThingDifferent += (object sender, Guid e) => {
                Console.WriteLine(e.ToString());
            };

            Program.UserDefined += (object abc, string str, bool istrue) =>
            {
                Console.WriteLine(abc.ToString());
                Console.WriteLine(str);
                Console.WriteLine(istrue.ToString());
            };

            //Invoke events
            //eventName.invoke()
            DoSomething.Invoke();
            SomeThingDifferent.Invoke(new Program(), Guid.NewGuid());
            Program.UserDefined.Invoke(new Program(), "Greetings", true);

          
        }


    }
}
