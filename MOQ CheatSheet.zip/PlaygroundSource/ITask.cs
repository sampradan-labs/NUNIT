﻿namespace PlaygroundSource
{
    public interface ITask
    {
        bool Perform();
    }

    public class CodeTask : ITask
    {
        private ITask task;

        //constructor injection
        public CodeTask(ITask ptask)
        {
            this.task = ptask;
            ptask.Perform();
        }

        public bool Perform()
        {
            return true;
        }
    }
}