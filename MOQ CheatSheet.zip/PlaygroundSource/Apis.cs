﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks.Sources;

namespace PlaygroundSource
{
   
    public class Apis : IStatus
    {

        public string WorkStatus { get; private set; }

        //public void UpdateStatus()
        //{
        //    throw new NotImplementedException();
        //}

        public void Work() {
            ((IStatus)this).UpdateStatus();
        }

        public void Work(ITask task)
        {
            task.Perform();
            ((IStatus)this).UpdateStatus();

        }

        void IStatus.UpdateStatus()
        {
            WorkStatus = "60% complete.";
        }
    }
}
