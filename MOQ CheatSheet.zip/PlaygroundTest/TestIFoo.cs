﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace PlaygroundTest
{
    [TestFixture]
    public class TestIFoo
    {
        [Test]
        public void Test_DoSomething() {
            Mock<IFoo> mock = new Mock<IFoo>();
            bool b = mock.Object.DoSomething("abc");
            Assert.AreEqual(false, b);   //NUnit
            mock.Verify();  //Mock set creation happened successfully
        }
    }
}
