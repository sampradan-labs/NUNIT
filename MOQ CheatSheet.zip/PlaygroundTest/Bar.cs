﻿namespace PlaygroundTest
{
    public class Bar
    {
        public Bar()
        {
        }
    }
}