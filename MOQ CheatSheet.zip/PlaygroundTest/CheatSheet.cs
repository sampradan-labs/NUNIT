﻿using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace PlaygroundTest
{
    [TestFixture]
    public class Simple
    {
        Moq.Mock<IFoo> mock = new Moq.Mock<IFoo>();

        [Test]
        public void Test_Interface_DoSomething()
        {
            //setup the mock, creating a behavior similar to dosomething
            //coz, DoSomething() returns a boolean, our mock will also return a boolean expectation

            mock.Setup(objFoo => objFoo.DoSomething(Moq.It.IsNotNull<string>()))
                                       .Returns(() => { Console.WriteLine("Done Something"); return true; });
            mock.Object.DoSomething("coding");
            mock.Verify(m=>m.DoSomething("coding"), Times.AtLeastOnce);

        }

        

        [Test]
        public void Test_Interface_Refs()
        {
            //creating an instance of the class
            var instance = new Bar();

            //Mock setup
            mock.Setup(objFoo => objFoo.Submit(ref instance)).Verifiable();
        }

        [Test]
        public void Test_Interface_Arguments()
        {
            mock.Setup(objFoo => objFoo.DoSomethingStringy(Moq.It.IsAny<string>())).Returns((string s) => s.ToLower());
            mock.Setup(objFoo => objFoo.DoSomething(Moq.It.IsInRange(18, 99, Moq.Range.Inclusive), Moq.It.IsNotNull<string>())).CallBase();
        }


        [Test]
        public void Test_Interface_Throw_Exceptions()
        {
            mock.Setup(objFoo => objFoo.DoSomething(Moq.It.IsRegex("<script>.*</script>", System.Text.RegularExpressions.RegexOptions.Multiline))).Throws<InvalidOperationException>();
        }

        [Test]
        public void Test_Interface_LazyEval()
        {
            int count = 10;
            //straight forward evaluation
            mock.Setup(objFoo => objFoo.GetCount()).Returns(count);

            //lazy evaluation using delegate / anonymous functions / lambdas
            mock.Setup(objFoo => objFoo.GetCount()).Returns(() => count);
        }


        [Test]
        public void Test_Interface_LazyEval_Returns_DifferentValues()
        {
            int count = 10;
            //lazy evaluation using delegate / anonymous functions / lambdas
            mock.Setup(objFoo => objFoo.GetCount()).Returns(() => count)
                                                    .Callback(() => count++);
            Console.WriteLine(mock.Object.GetCount());
        }
    }
}
