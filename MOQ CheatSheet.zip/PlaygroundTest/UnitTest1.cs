using Moq;
using NUnit.Framework;
using PlaygroundSource;
using System.Diagnostics;

namespace PlaygroundTest
{
    [TestFixture]
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test_WhenWorkIsCalled_PerformShouldBeCalled_Once() {
            Mock<ITask> mockTask = new Mock<ITask>();
            //mockTask.Setup(objTask => objTask.Perform()).Verifiable();  //watcher - testdouble / spy
            //mockTask.Setup(objTask => objTask.Perform()).Returns(true);
            mockTask.Setup(objTask => objTask.Perform())
                                        .Returns(true)
                                        .Callback(() => { Debug.WriteLine("Callback invoked"); })
                                        .Verifiable();
            /*
             class mockTask{
                bool Perform(){
                    return true;
                }
            }
             */

            //make the real call
            new Apis().Work(mockTask.Object);
           
            mockTask.Verify(obj => obj.Perform(), Times.Once);
            mockTask.VerifyAll();
        }

        [Test]
        public void Test_WhenWorkIsCalled_WithConcreteClass_PerformShouldBeCalled_Once() {
            Mock<ITask> mockTask = new Mock<ITask>();
            mockTask.Setup(task => task.Perform())
                                        .Returns(true)
                                        .Callback(() => { Debug.WriteLine("Callback invoked"); })
                                        .Verifiable();
        

            
            new Apis().Work(new CodeTask(mockTask.Object)); //Here, we are doing the same job
                                                            //but using the CodeTask class : ITask

            //new CodeTask(mockTask.Object);
            mockTask.Verify(t => t.Perform(), Times.Once);
        }

    }

    
}