﻿namespace PlaygroundTest
{
    public interface IFoo
    {
        bool DoSomething(string work);
        void Submit(ref Bar instance);
        string DoSomethingStringy(string v);
        int GetCount();
        bool DoSomething(int v1, string v2);
    }
}